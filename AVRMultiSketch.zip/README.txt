                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3279087
AVRMultiSketch by JMadison is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is an AVRMultiSketch implementation example of multiple Arduino sketches loaded onto a single device.  On power-up you either select a different sketch by pressing one of three buttons, or do nothing and the previous sketch will be loaded.  The flash memory is not modified to accomplish this.  Curious how it works?  See my  <a href="https://github.com/JonMackey/AVRMultiSketch" name="AVRMultiSketch" title="an Objective-C OS X app that relinks and edits compiled sketch code (elf files) to allow multiple Arduino sketches to be loaded on and run from a single AVR mcu">AVRMultiSketch</a> GitHub readme for more details.

The example board is named "AVR Programmer w/HV".  This is also described in the readme and several pictures above.

Message me if you have any questions.

The bracket STL is a minimal mounting bracket for a 50x70mm board.  It uses 4 - M2x5 screws.

I printed it using draft quality, 20% fill.